from flask import Flask, render_template, request
import re

app = Flask(__name__)

def clean_text(text):
    if not text:
        return ""
    text = " ".join(text.split())
    text = re.sub(r'[^A-Za-z0-9., ]+', '', text)
    return text

def summarize_text(text):
    if not text:
        return "No text provided."
    sentences = text.split(".")
    words = text.lower().split()
    word_count = {w: words.count(w) for w in words}
    scores = {s: sum(word_count.get(w,0) for w in s.lower().split()) for s in sentences}
    top = sorted(scores, key=scores.get, reverse=True)[:2]
    return ". ".join(top).strip()

def analyze_sentiment(text):
    if not text:
        return "Neutral"
    pos = ["good","great","excellent","happy","love","amazing","impressive","outstanding"]
    neg = ["bad","terrible","sad","hate","angry","poor","overheats","slower","minor","issues"]
    words = text.lower().split()
    score = sum(1 for w in words if w in pos) - sum(1 for w in words if w in neg)
    if score>0:
        return "Positive"
    elif score<0:
        return "Negative"
    else:
        return "Neutral"

@app.route("/", methods=["GET","POST"])
def home():
    data = {"original":"", "summary":"", "sentiment":"", "words":0, "sentences":0, "characters":0}

    if request.method == "POST":
        user_text = request.form.get("text","")
        cleaned = clean_text(user_text)
        data["original"] = user_text
        data["summary"] = summarize_text(cleaned)
        data["sentiment"] = analyze_sentiment(cleaned)
        data["words"] = len(cleaned.split())
        data["sentences"] = len(cleaned.split("."))
        data["characters"] = len(cleaned)

    return render_template("index.html", **data)

if __name__ == "__main__":
    app.run(debug=True)
